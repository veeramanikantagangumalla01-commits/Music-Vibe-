package com.vibemusic.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

private val Bg = Color(0xFF101014)
private val Panel = Color(0xFF202027)
private val Green = Color(0xFF1ED760)
private val Muted = Color(0xFFAAAAB4)

data class Track(val title: String, val uri: Uri, val subtitle: String = "On your device")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val player = ExoPlayer.Builder(this).build()
        setContent { VibeMusicApp(player) }
    }
    override fun onDestroy() { super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VibeMusicApp(player: ExoPlayer) {
    var tracks by remember { mutableStateOf(listOf<Track>()) }
    var current by remember { mutableStateOf<Track?>(null) }
    var playing by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Home") }
    var favorites by remember { mutableStateOf(setOf<Uri>()) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val added = uris.map { uri -> Track(title = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "Audio track", uri = uri) }
        tracks = (tracks + added).distinctBy { it.uri }
        if (current == null && tracks.isNotEmpty()) current = tracks.first()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Green, onPrimary = Color.Black,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF17171D), contentColor = Color.White) {
                listOf("Home", "Search", "Library").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item, onClick = { tab = item },
                        icon = { Icon(when(item) { "Home" -> Icons.Default.Home; "Search" -> Icons.Default.Search; else -> Icons.Default.LibraryMusic }, null) },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, indicatorColor = Panel, selectedTextColor = Green, unselectedTextColor = Muted)
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).background(Green, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.GraphicEq, null, tint = Color.Black)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text("VIBE MUSIC", fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = 1.5.sp)
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { picker.launch(arrayOf("audio/*")) }) { Icon(Icons.Default.Add, "Add music", tint = Green) }
                }
                Spacer(Modifier.height(22.dp))
                when(tab) {
                    "Home" -> HomeScreen(tracks, favorites, current, onAdd = { picker.launch(arrayOf("audio/*")) }, onPlay = { playTrack(it, player) { current = it; playing = true }; current = it; playing = true }, onFavorite = { uri -> favorites = if(uri in favorites) favorites - uri else favorites + uri })
                    "Search" -> {
                        Text("Find your sound", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search your music") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Green, unfocusedBorderColor = Muted))
                        Spacer(Modifier.height(12.dp))
                        TrackList(tracks.filter { it.title.contains(query, true) }, current, favorites, onPlay = { playTrack(it, player) { current = it; playing = true }; current = it; playing = true }, onFavorite = { uri -> favorites = if(uri in favorites) favorites - uri else favorites + uri })
                    }
                    else -> {
                        Text("Your Library", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("${tracks.size} tracks · ${favorites.size} liked", color = Muted)
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { tab = "Favorites" }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Favorite, null, tint = Green)
                            Spacer(Modifier.width(12.dp))
                            Text("Liked songs", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.weight(1f))
                            Text("${favorites.size}", color = Muted)
                        }
                        Spacer(Modifier.height(12.dp))
                        TrackList(tracks, current, favorites, onPlay = { playTrack(it, player) { current = it; playing = true }; current = it; playing = true }, onFavorite = { uri -> favorites = if(uri in favorites) favorites - uri else favorites + uri })
                    }
                }
                Spacer(Modifier.weight(1f))
                current?.let { track ->
                    MiniPlayer(track, playing, onToggle = {
                        if (player.isPlaying) { player.pause(); playing = false }
                        else { if (player.currentMediaItem == null) playTrack(track, player) {}; player.play(); playing = true }
                    })
                }
            }
        }
    }
}

private fun playTrack(track: Track, player: ExoPlayer, done: () -> Unit) {
    player.setMediaItem(MediaItem.fromUri(track.uri))
    player.prepare()
    player.play()
    done()
}

@Composable
fun HomeScreen(tracks: List<Track>, favorites: Set<Uri>, current: Track?, onAdd: () -> Unit, onPlay: (Track) -> Unit, onFavorite: (Uri) -> Unit) {
    Text("Good vibes only ✨", fontSize = 27.sp, fontWeight = FontWeight.Bold)
    Text("Your music, your way.", color = Muted)
    Spacer(Modifier.height(22.dp))
    Row(Modifier.fillMaxWidth().background(BrushColor(), RoundedCornerShape(18.dp)).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("YOUR MUSIC", color = Color.Black.copy(alpha = .7f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Bring your
playlist to life", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 23.sp, lineHeight = 27.sp)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Green)) { Text("Add music") }
        }
        Icon(Icons.Default.Headphones, null, tint = Color.Black, modifier = Modifier.size(76.dp))
    }
    Spacer(Modifier.height(22.dp))
    Text("Recently added", fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    if (tracks.isEmpty()) {
        Box(Modifier.fillMaxWidth().padding(vertical = 24.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.LibraryMusic, null, tint = Muted, modifier = Modifier.size(42.dp))
                Spacer(Modifier.height(8.dp))
                Text("Your library is waiting", color = Muted)
                Text("Tap Add music to choose audio files", color = Muted, fontSize = 12.sp)
            }
        }
    } else TrackList(tracks.take(5), current, favorites, onPlay, onFavorite)
}

@Composable
fun TrackList(tracks: List<Track>, current: Track?, favorites: Set<Uri>, onPlay: (Track) -> Unit, onFavorite: (Uri) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        items(tracks, key = { it.uri.toString() }) { track ->
            Row(Modifier.fillMaxWidth().clickable { onPlay(track) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).background(Panel, RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.MusicNote, null, tint = if(track == current) Green else Muted)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(track.subtitle, color = Muted, fontSize = 12.sp)
                }
                IconButton(onClick = { onFavorite(track.uri) }) {
                    Icon(if(track.uri in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if(track.uri in favorites) Green else Muted)
                }
                IconButton(onClick = { onPlay(track) }) { Icon(Icons.Default.PlayArrow, null, tint = Color.White) }
            }
        }
    }
}

@Composable
fun MiniPlayer(track: Track, playing: Boolean, onToggle: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).background(Color(0xFF292932), RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Album, null, tint = Green, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text("Vibe Music · Local audio", color = Muted, fontSize = 11.sp)
        }
        IconButton(onClick = onToggle) { Icon(if(playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Green) }
    }
}

@Composable
private fun BrushColor() = Color(0xFF1ED760)
