# Vibe Music — Android MVP

A Spotify-inspired starter Android app built with Kotlin, Jetpack Compose and AndroidX Media3.

## Features
- Dark music-app interface with Home, Search and Library tabs
- Import multiple audio files from the device using Android's document picker
- Play and pause imported audio with Media3 ExoPlayer
- Search imported track names
- Like/unlike tracks (in-memory for this first MVP)

## Open and run
1. Install Android Studio (current stable version).
2. Choose **Open** and select this `VibeMusic` folder.
3. Allow Gradle sync to finish (internet is needed for dependencies).
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press **Run**.

## Notes
- This MVP plays audio files the user selects; it does not include copyrighted songs or a Spotify catalogue.
- Favorites and imported track lists are kept in app memory for this first version and reset when the app process is recreated.
- For a production streaming service, you would need licensed music/catalogue access, a backend, accounts, persistent playlists, artwork, and distribution setup.
